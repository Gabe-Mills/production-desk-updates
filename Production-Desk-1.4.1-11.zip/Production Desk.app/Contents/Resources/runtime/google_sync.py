"""Optional Google integration. All OAuth/API traffic stays in the local server."""
import base64
from datetime import date, timedelta
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, quote, urlsplit
from urllib.request import Request, urlopen
from film import validate_uss

SCOPES = ['openid', 'email', 'https://www.googleapis.com/auth/spreadsheets',
          'https://www.googleapis.com/auth/calendar.events',
          'https://www.googleapis.com/auth/calendar.calendarlist.readonly']

class GoogleError(ValueError):
    pass


def request_json(url, method='GET', data=None, token=None, form=False):
    headers = {'Accept': 'application/json'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    body = None
    if data is not None:
        body = (urlencode(data) if form else json.dumps(data)).encode()
        headers['Content-Type'] = 'application/x-www-form-urlencoded' if form else 'application/json'
    try:
        with urlopen(Request(url, body, headers, method=method), timeout=30) as response:
            raw = response.read()
            return json.loads(raw) if raw else {}
    except HTTPError as exc:
        # Do not return token responses or private response bodies to the browser/log.
        error = GoogleError({401: 'Reconnect your Google account in Settings.',
                             403: 'Google denied access. Check sharing permissions, enabled APIs, and account consent.',
                             404: 'Google could not find that sheet or calendar.',
                             409: 'Google already has this event.',
                             429: 'Google is busy. Please try again shortly.'}.get(exc.code, 'Google could not complete the request.'))
        error.status = exc.code
        raise error from None
    except (URLError, TimeoutError, OSError):
        raise GoogleError('Could not reach Google. Check your internet connection and try again.') from None


def sheet_id(value):
    value = str(value).strip()
    if re.fullmatch(r'[A-Za-z0-9_-]{20,160}', value):
        return value
    parsed = urlsplit(value)
    match = re.fullmatch(r'/spreadsheets/d/([A-Za-z0-9_-]{20,160})(?:/.*)?', parsed.path)
    if parsed.scheme == 'https' and parsed.hostname == 'docs.google.com' and match:
        return match.group(1)
    raise GoogleError('Paste a Google Sheets link for your G-Casper call sheet.')


def col(index):
    text = ''
    index += 1
    while index:
        index, rem = divmod(index - 1, 26)
        text = chr(65 + rem) + text
    return text


def schedule(project, scenario_id):
    validate_uss(project)
    scenario = next((s for s in project['stripboards'] if s['id'] == scenario_id), None)
    if not scenario:
        raise GoogleError('Choose an existing schedule scenario.')
    cal = next((c for c in project['calendars'] if c['id'] == scenario['calendar']), None)
    start = next((e['date'][:10] for e in (cal or {}).get('events', []) if e['type'] == 'start'), None)
    off = {e['date'][:10] for e in (cal or {}).get('events', []) if e['type'] == 'dayOff'}
    weekdays = (cal or {}).get('daysOff', [])
    if len(set(weekdays)) == 7:
        raise GoogleError('Leave at least one weekday available for shooting.')
    day_date = date.fromisoformat(start) if start else None
    lookup = {b['id']: b for b in project['breakdowns']}
    days = []
    for group in scenario['boards'][0]['breakdownIds']:
        if not isinstance(group, list):
            continue
        if day_date:
            guard = 0
            while (day_date.weekday() + 1) % 7 in weekdays or day_date.isoformat() in off:
                day_date += timedelta(days=1)
                guard += 1
                if guard > 36500:
                    raise GoogleError('Could not find an available shooting date.')
        days.append({'day': len(days) + 1, 'date': day_date.isoformat() if day_date else None,
                     'scenes': [lookup[bid] for bid in group]})
        if day_date:
            day_date += timedelta(days=1)
    return scenario, days


class Keychain:
    def __init__(self, helper):
        self.helper = helper

    def call(self, operation, value=None):
        if not self.helper.is_file():
            raise GoogleError('Google sign-in needs the Mac application build.')
        result = subprocess.run([str(self.helper), operation], input=json.dumps(value).encode() if value is not None else None,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
        if result.returncode:
            raise GoogleError('Google credentials could not be accessed in macOS Keychain.')
        return json.loads(result.stdout) if result.stdout else None

    def load(self): return self.call('get')
    def save(self, value): self.call('set', value)
    def delete(self): self.call('delete')


class GoogleIntegration:
    def __init__(self, root, data_folder, transport=request_json, store=None):
        self.root = Path(root)
        self.folder = Path(data_folder)
        self.preferences_path = self.folder / 'app-settings.json'
        self.transport = transport
        self.store = store or Keychain(self.root / 'tools/google_keychain')
        self.lock = threading.RLock()
        self.pending = None
        self.tokens = None
        self.plans = {}
        self.connection_error = ''
        self.config = {}
        for config_path in [self.folder / 'google-oauth.json', self.root / 'google-oauth.json']:
            if config_path.is_file():
                try:
                    raw = json.loads(config_path.read_text())
                    self.config = raw.get('installed', raw)
                    if not self.config.get('client_id', '').endswith('.apps.googleusercontent.com'):
                        raise ValueError()
                except (OSError, ValueError, AttributeError):
                    self.config = {}
                break
        if self.config:
            try:
                self.tokens = self.store.load()
                if self.tokens and self.tokens.get('client_id') != self.config['client_id']:
                    self.tokens = None
            except GoogleError as exc:
                self.connection_error = str(exc)

    def preferences(self):
        try:
            value = json.loads(self.preferences_path.read_text())
        except (OSError, ValueError):
            value = {}
        return {'theme': value.get('theme', 'light') if value.get('theme') in ('light', 'dark') else 'light',
                'gcasperLinks': value.get('gcasperLinks', {}), 'calendarId': value.get('calendarId', 'primary')}

    def save_preferences(self, value):
        with self.lock:
            current = self.preferences()
            if value.get('theme') in ('light', 'dark'):
                current['theme'] = value['theme']
            if isinstance(value.get('gcasperLinks'), dict):
                current['gcasperLinks'] = {str(k): str(v)[:1000] for k, v in value['gcasperLinks'].items()}
            if isinstance(value.get('calendarId'), str):
                current['calendarId'] = value['calendarId'][:1000]
            self.folder.mkdir(parents=True, exist_ok=True)
            temp = self.preferences_path.with_suffix('.tmp')
            fd = os.open(str(temp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, 'w') as stream:
                json.dump(current, stream)
            temp.replace(self.preferences_path)
            return current

    def status(self):
        with self.lock:
            pending = bool(self.pending and time.time() - self.pending['created'] < 600)
            return {'configured': bool(self.config), 'connected': bool(self.tokens),
                    'email': (self.tokens or {}).get('email', ''), 'pending': pending,
                    'error': self.connection_error, 'preferences': self.preferences()}

    def connect(self, redirect):
        with self.lock:
            if not self.config:
                raise GoogleError('Google sign-in is awaiting Production Desk’s Google app registration.')
            verifier = secrets.token_urlsafe(48)
            self.pending = {'state': secrets.token_urlsafe(32), 'verifier': verifier,
                            'redirect': redirect, 'created': time.time()}
            challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
            self.connection_error = ''
            query = {'client_id': self.config['client_id'], 'redirect_uri': redirect, 'response_type': 'code',
                     'scope': ' '.join(SCOPES), 'state': self.pending['state'], 'code_challenge': challenge,
                     'code_challenge_method': 'S256', 'access_type': 'offline', 'prompt': 'consent select_account'}
            return {'url': 'https://accounts.google.com/o/oauth2/v2/auth?' + urlencode(query)}

    def callback(self, query):
        with self.lock:
            pending = self.pending
            if not pending or time.time() - pending['created'] > 600 or not secrets.compare_digest(query.get('state', [''])[0], pending['state']):
                raise GoogleError('This sign-in request has expired. Start again in Settings.')
            self.pending = None
            try:
                if query.get('error') or not query.get('code'):
                    raise GoogleError('Google sign-in was cancelled. You can try again in Settings.')
                data = {'client_id': self.config['client_id'], 'code': query['code'][0],
                        'code_verifier': pending['verifier'], 'redirect_uri': pending['redirect'], 'grant_type': 'authorization_code'}
                if self.config.get('client_secret'):
                    data['client_secret'] = self.config['client_secret']
                tokens = self.transport('https://oauth2.googleapis.com/token', 'POST', data, form=True)
                if not tokens.get('access_token') or not tokens.get('refresh_token'):
                    raise GoogleError('Google did not grant offline access. Reconnect and allow access in the consent screen.')
                user = self.transport('https://openidconnect.googleapis.com/v1/userinfo', token=tokens['access_token'])
                tokens.update({'email': user.get('email', ''), 'expires_at': time.time() + tokens.get('expires_in', 3600),
                               'client_id': self.config['client_id']})
                self.store.save(tokens)
                self.tokens = tokens
                self.plans.clear()
            except GoogleError as exc:
                self.connection_error = str(exc)
                raise

    def disconnect(self):
        with self.lock:
            if self.tokens:
                try:
                    self.transport('https://oauth2.googleapis.com/revoke', 'POST',
                                   {'token': self.tokens.get('refresh_token') or self.tokens['access_token']}, form=True)
                except GoogleError:
                    raise GoogleError('Could not revoke Google access. Check your connection and try disconnecting again.') from None
            self.store.delete()
            self.tokens = self.pending = None
            self.plans.clear()
            self.connection_error = ''
            return self.status()

    def token(self):
        with self.lock:
            if not self.tokens:
                raise GoogleError('Connect a Google account in Settings first.')
            if self.tokens.get('expires_at', 0) < time.time() + 60:
                data = {'client_id': self.config['client_id'], 'refresh_token': self.tokens['refresh_token'], 'grant_type': 'refresh_token'}
                if self.config.get('client_secret'): data['client_secret'] = self.config['client_secret']
                fresh = self.transport('https://oauth2.googleapis.com/token', 'POST', data, form=True)
                updated = dict(self.tokens, **fresh, expires_at=time.time() + fresh.get('expires_in', 3600))
                self.store.save(updated)
                self.tokens = updated
            return self.tokens['access_token']

    def api(self, path, method='GET', data=None):
        return self.transport('https://www.googleapis.com/' + path, method, data, token=self.token())

    def calendars(self):
        items = []
        page = None
        while True:
            query = {'minAccessRole': 'writer', 'maxResults': 250}
            if page: query['pageToken'] = page
            value = self.api('calendar/v3/users/me/calendarList?' + urlencode(query))
            items.extend({'id': c['id'], 'name': c.get('summary', c['id'])} for c in value.get('items', []))
            page = value.get('nextPageToken')
            if not page: return {'calendars': items}

    def read_ranges(self, sid, ranges):
        query = [('ranges', r) for r in ranges] + [('valueRenderOption', 'FORMULA')]
        return self.api('sheets/v4/spreadsheets/' + sid + '/values:batchGet?' + urlencode(query)).get('valueRanges', [])

    def remember(self, plan, summary):
        with self.lock:
            self.plans = {k: v for k, v in self.plans.items() if time.time() - v['created'] < 300}
            if len(self.plans) >= 10:
                self.plans.pop(next(iter(self.plans)))
            key = secrets.token_urlsafe(24)
            plan.update({'created': time.time(), 'email': (self.tokens or {}).get('email')})
            self.plans[key] = plan
            return dict(summary, planId=key)

    def preview_sheet(self, project, scenario_id, link):
        scenario, days = schedule(project, scenario_id)
        sid = sheet_id(link)
        meta = self.api('sheets/v4/spreadsheets/' + sid + '?fields=spreadsheetId,spreadsheetUrl,properties(title),sheets(properties)')
        tabs = {t['properties']['title']: t['properties'] for t in meta['sheets']}
        for name in ('Breakdown', 'Cast', 'Days'):
            if name not in tabs:
                raise GoogleError('This G-Casper sheet needs Breakdown, Cast, and Days tabs.')
        # Reads stay bounded to each template's existing cells.
        ranges = ["'Breakdown'!A1:AD" + str(min(tabs['Breakdown']['gridProperties']['rowCount'], 5000)),
                  "'Cast'!A1:I" + str(min(tabs['Cast']['gridProperties']['rowCount'], 5000)),
                  "'Days'!A1:F" + str(min(tabs['Days']['gridProperties']['rowCount'], 5000))]
        snapshot = self.read_ranges(sid, ranges)
        values = [v.get('values', []) for v in snapshot]
        breakdown, cast, day_rows = values
        if not breakdown or breakdown[0][:8] != ['Sc', 'Pgs', 'D/N', 'ScriptD', 'I/E', 'Set', 'Description', 'Cast']:
            raise GoogleError('The Breakdown columns do not match the supported G-Casper template.')
        if not cast or cast[0][:3] != ['ID', 'Role', 'Cast'] or not day_rows or day_rows[0][:2] != ['Day #', 'Date']:
            raise GoogleError('The Cast or Days columns do not match the supported G-Casper template.')
        writes = []
        def cell(tab, row, column, value):
            writes.append({'range': "'" + tab + "'!" + col(column) + str(row), 'values': [[value]]})
        cats = {c['id']: c['ucid'] for c in project['categories']}
        elements = {e['id']: e for e in project['elements']}
        def names(scene, ucids):
            return ', '.join(elements[e]['name'] for e in scene['elements'] if cats[elements[e]['category']] in ucids)
        def key(value): return str(value).strip().casefold()
        def content(row, index): return row[index] if len(row) > index else ''
        cast_map = {key(content(row, 1)): str(content(row, 0)) for row in cast[1:] if content(row, 1) and content(row, 0)}
        free_cast = [r for r in range(2, min(tabs['Cast']['gridProperties']['rowCount'],5000) + 1)
                     if r > len(cast) or not any(content(cast[r-1], c) for c in [1, 2, 4, 5, 6, 7])]
        used_ids = {str(content(row, 0)) for row in cast[1:] if content(row, 1)}
        cast_added = 0
        incoming_cast = [e for e in project['elements'] if cats[e['category']] == 100 and any(e['id'] in b['elements'] for b in project['breakdowns'] if b['type'] == 'scene')]
        for e in incoming_cast:
            if key(e['name']) in cast_map: continue
            if not free_cast: raise GoogleError('Add more blank rows to the G-Casper Cast tab, then preview again.')
            row = free_cast.pop(0)
            preferred = str(content(cast[row-1], 0)) if row <= len(cast) else ''
            candidate = preferred or str(e.get('elementId') or '')
            if not re.fullmatch(r'\d+', candidate) or candidate in used_ids:
                candidate = str(max([int(v) for v in used_ids if v.isdigit()] or [0]) + 1)
            used_ids.add(candidate)
            cast_map[key(e['name'])] = candidate
            cell('Cast', row, 0, candidate); cell('Cast', row, 1, e['name'])
            cast_added += 1
        existing = {}
        for row, data in enumerate(breakdown[1:], 2):
            if content(data, 0):
                if key(data[0]) in existing: raise GoogleError('The G-Casper Breakdown contains duplicate scene numbers. Resolve them before syncing.')
                existing[key(data[0])] = row
        blank = [r for r in range(2, min(tabs['Breakdown']['gridProperties']['rowCount'],5000) + 1)
                 if r > len(breakdown) or not any(content(breakdown[r-1], c) for c in range(29))]
        headers = breakdown[0]
        categories = {'Props': [104], 'MU/Hair': [107], 'Costume': [106], 'SetDress': [116, 115, 117],
                      'SPFX': [105, 122], 'Camera': [110], 'Sound': [113], 'Grip/Elec': [111,112],
                      'Stunts': [102], 'Locations': [6], 'PicVeh': [103], 'VFX': [121],
                      'AddlEquip': [119], 'AddlLabor': [120], 'Misc1': [125,126],
                      'Extras / Background Notes': [101]}
        scenes = [b for b in project['breakdowns'] if b['type'] == 'scene']
        if any(not str(b['scene'] or '').strip() for b in scenes) or len({key(b['scene']) for b in scenes}) != len(scenes):
            raise GoogleError('Give each scene a unique scene number before syncing.')
        added = updated = 0
        for scene in scenes:
            row = existing.get(key(scene['scene']))
            if row: updated += 1
            else:
                if not blank: raise GoogleError('Add more blank rows to the G-Casper Breakdown tab, then preview again.')
                row = blank.pop(0); added += 1
            core = [str(scene['scene']), scene['pages'] or 0, names(scene,[2]), names(scene,[3]), names(scene,[1]),
                    names(scene,[0]), scene['description'] or '',
                    ', '.join(cast_map[key(elements[e]['name'])] for e in scene['elements'] if cats[elements[e]['category']] == 100)]
            for c, value in enumerate(core): cell('Breakdown', row, c, value)
            for header, ucids in categories.items():
                value = names(scene, ucids)
                if value and header in headers: cell('Breakdown', row, headers.index(header), value)
            if scene.get('comments') and 'Notes' in headers: cell('Breakdown', row, headers.index('Notes'), scene['comments'])
        day_map = {str(content(row,0)): i for i,row in enumerate(day_rows[1:],2) if str(content(row,0)).isdigit()}
        dated = 0
        for day in days:
            if not day['date']: continue
            row = day_map.get(str(day['day']))
            if not row: raise GoogleError('Add numbered shooting-day rows to the G-Casper Days tab, then preview again.')
            serial = (date.fromisoformat(day['date']) - date(1899,12,30)).days
            cell('Days', row, 1, serial); dated += 1
        # This owned tab carries actual shooting order without altering G-Casper's call-sheet choices.
        schedule_name = 'Production Desk Schedule'
        schedule_values = [['Day','Date','Scene','INT/EXT','Set','Day/Night','Synopsis','Pages','Minutes','Cast IDs','Location','Notes']]
        for day in days:
            for b in day['scenes']:
                schedule_values.append([day['day'],day['date'] or '',str(b['scene'] or ''),names(b,[1]),
                    b['bannerText'] if b['type']=='banner' else names(b,[0]),names(b,[2]),b['description'] or '',
                    b['pages'] or 0,(b['duration'] or 0)/60000,
                    ', '.join(cast_map[key(elements[e]['name'])] for e in b['elements'] if cats[elements[e]['category']] == 100),
                    names(b,[6]),b['comments'] or ''])
        if schedule_name in tabs:
            owned = tabs[schedule_name]
            if owned['gridProperties']['rowCount'] < len(schedule_values) or owned['gridProperties']['columnCount'] < 12:
                raise GoogleError('Expand the Production Desk Schedule tab to fit this schedule.')
            ranges.append("'Production Desk Schedule'!A1:L" + str(min(owned['gridProperties']['rowCount'],5000)))
            snapshot = self.read_ranges(sid, ranges)
            old_count = len(snapshot[-1].get('values',[]))
            schedule_values += [['']*12 for _ in range(max(0,old_count-len(schedule_values)))]
        writes.append({'range': "'Production Desk Schedule'!A1", 'values':schedule_values})
        plan = {'kind':'sheet', 'sid':sid,'ranges':ranges,'snapshot':snapshot,'writes':writes,
                'createSchedule':schedule_name not in tabs,'scheduleRows':max(1000,len(schedule_values)),
                'url':meta['spreadsheetUrl']}
        return self.remember(plan, {'kind':'sheet','title':meta['properties']['title'],'added':added,'updated':updated,
                                   'castAdded':cast_added,'days':dated,'scenes':len(scenes),'scenario':scenario['name']})

    def calendar_events(self, calendar_id, tag):
        events = []
        query = {'privateExtendedProperty':'productionDeskScenario='+tag, 'maxResults':2500, 'showDeleted':'false'}
        while True:
            value = self.api('calendar/v3/calendars/'+quote(calendar_id,safe='')+'/events?'+urlencode(query))
            events += value.get('items',[])
            if not value.get('nextPageToken'): return events
            query['pageToken'] = value['nextPageToken']

    def preview_calendar(self, project, scenario_id, calendar_id):
        scenario, days = schedule(project,scenario_id)
        if not days or any(not d['date'] for d in days):
            raise GoogleError('Set the first shooting date and add shooting days in Production settings.')
        calendar_id = str(calendar_id or 'primary')
        meta = self.api('calendar/v3/users/me/calendarList/'+quote(calendar_id,safe=''))
        tag = hashlib.sha256((project['id']+scenario_id).encode()).hexdigest()[:32]
        existing = self.calendar_events(calendar_id,tag)
        body = []
        cats = {c['id']:c['ucid'] for c in project['categories']}
        elements = {e['id']:e for e in project['elements']}
        for day in days:
            location = ', '.join(dict.fromkeys(elements[e]['name'] for b in day['scenes'] for e in b['elements'] if cats[elements[e]['category']]==6))
            lines = []
            for b in day['scenes']:
                if b['type']=='banner': lines.append(b['bannerText'] or '')
                else:
                    setting = ', '.join(elements[e]['name'] for e in b['elements'] if cats[elements[e]['category']]==0)
                    lines.append('Scene '+str(b['scene'])+' — '+setting+'\n'+(b['description'] or ''))
            event_id = hashlib.sha256((tag+':'+str(day['day'])).encode()).hexdigest()
            body.append({'id':event_id,'summary':(project['project'] or project['name'])+' — Shoot day '+str(day['day']),
                         'description':scenario['name']+'\n\n'+'\n\n'.join(lines),'location':location,
                         'start':{'date':day['date']},'end':{'date':(date.fromisoformat(day['date'])+timedelta(days=1)).isoformat()},
                         'extendedProperties':{'private':{'productionDeskScenario':tag}}})
        desired = {e['id'] for e in body}
        removed = [e['id'] for e in existing if e['id'] not in desired]
        return self.remember({'kind':'calendar','calendarId':calendar_id,'tag':tag,'snapshot':existing,'events':body,'removed':removed},
                             {'kind':'calendar','title':meta.get('summary',calendar_id),'days':len(body),'removed':len(removed),'scenario':scenario['name']})

    def commit(self, plan_id):
        # Serialize commits so repeated clicks cannot consume a preview twice.
        with self.lock:
            plan = self.plans.pop(str(plan_id), None)
            if not plan or time.time()-plan['created']>300 or plan['email']!=(self.tokens or {}).get('email'):
                raise GoogleError('This preview has expired. Preview the transfer again.')
            if plan['kind']=='sheet':
                if self.read_ranges(plan['sid'],plan['ranges']) != plan['snapshot']:
                    raise GoogleError('The Google Sheet changed since your preview. Preview again before syncing.')
                if plan['createSchedule']:
                    self.api('sheets/v4/spreadsheets/'+plan['sid']+':batchUpdate','POST',{'requests':[{'addSheet':{'properties':{
                        'title':'Production Desk Schedule','gridProperties':{'rowCount':plan['scheduleRows'],'columnCount':12,'frozenRowCount':1}}}}]})
                self.api('sheets/v4/spreadsheets/'+plan['sid']+'/values:batchUpdate','POST',{'valueInputOption':'RAW','data':plan['writes']})
                # Read actual values back, including scene numbers and cast IDs; formulas remain outside written cells.
                ranges = plan['ranges'][:3] + ["'Production Desk Schedule'!A1:L" + str(len(plan['writes'][-1]['values']))]
                checks = self.read_ranges(plan['sid'], ranges)
                by_tab = dict(zip(['Breakdown','Cast','Days','Production Desk Schedule'], [v.get('values',[]) for v in checks]))
                for write in plan['writes']:
                    tab, address = write['range'].split('!')
                    match = re.fullmatch(r'([A-Z]+)(\d+)', address)
                    column = 0
                    for letter in match.group(1): column = column*26+ord(letter)-64
                    row = int(match.group(2))-1
                    actual = by_tab.get(tab.strip("'"), [])
                    for r, values in enumerate(write['values']):
                        for c, expected in enumerate(values):
                            found = actual[row+r][column-1+c] if row+r<len(actual) and column-1+c<len(actual[row+r]) else ''
                            if found != expected:
                                raise GoogleError('Google accepted the transfer, but readback could not be verified. Preview again to check the sheet.')
                return {'synced':True,'url':plan['url']}
            calendar_id = plan['calendarId']
            if self.calendar_events(calendar_id,plan['tag']) != plan['snapshot']:
                raise GoogleError('Calendar events changed since your preview. Preview again before syncing.')
            prefix = 'calendar/v3/calendars/'+quote(calendar_id,safe='')+'/events'
            existing = {e['id'] for e in plan['snapshot']}
            for event in plan['events']:
                if event['id'] in existing:
                    body = {k:v for k,v in event.items() if k!='id'}
                    self.api(prefix+'/'+event['id'],'PATCH',body)
                else:
                    try: self.api(prefix,'POST',event)
                    except GoogleError as exc:
                        if getattr(exc,'status',None)==409:
                            found = self.api(prefix+'/'+event['id'])
                            if found.get('extendedProperties',{}).get('private',{}).get('productionDeskScenario') != plan['tag']: raise
                            self.api(prefix+'/'+event['id'],'PATCH',{k:v for k,v in event.items() if k!='id'})
                        else: raise
            for event_id in plan['removed']:
                self.api(prefix+'/'+event_id,'DELETE')
            confirmed = {e['id']:e for e in self.calendar_events(calendar_id,plan['tag'])}
            if any(event_id in confirmed for event_id in plan['removed']) or any(
                    any(confirmed.get(e['id'],{}).get(k)!=e[k] for k in ['summary','description','location','start','end'])
                    for e in plan['events']):
                raise GoogleError('Google accepted the transfer, but event readback could not be verified. Preview again to check the calendar.')
            return {'synced':True,'days':len(plan['events']),'url':'https://calendar.google.com/calendar/u/0/r'}
